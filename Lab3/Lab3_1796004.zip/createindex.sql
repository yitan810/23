CREATE INDEX ArticleSearch 
    ON Articles(articleAuthor, editionDate);